﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using LuckyPaw.Data;
using LuckyPaw.Models;
using LuckyPaw.Helpers;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Authorization;

namespace LuckyPaw.Controllers
{
    public class CartItemModelsController : Controller
    {
        private readonly LuckyPawContext _context;

        public CartItemModelsController(LuckyPawContext context)
        {
            _context = context;
        }

        // GET: CartItemModels
        public async Task<IActionResult> Index()
        {
            // Code below copied from http://learningprogramming.net/net/asp-net-core-mvc/build-shopping-cart-with-session-in-asp-net-core-mvc/
            // and updated

            var puppyCart = SessionHelper.GetObjectFromJson<List<CartItemModel>>(HttpContext.Session, "puppyCart");
            var trainingServicesCart = SessionHelper.GetObjectFromJson<List<CartItemModel>>(HttpContext.Session, "trainingServicesCart");

            if(puppyCart != null && trainingServicesCart != null)
                puppyCart.AddRange(trainingServicesCart);
            
            if (puppyCart != null)
                return View(puppyCart);
            else if (trainingServicesCart != null)
                return View(trainingServicesCart);
            else
            {
                List<CartItemModel> tempCartList = new List<CartItemModel>();
                CartItemModel tempCart = new CartItemModel { PricePuppyID = 0, PricePuppyDesc = "", PricePuppy = 0, TrainingServicesPriceID = 0,
                    TrainingName = "", PriceTraining = 0, CartQty = 0, Email = "" };

                tempCartList.Add(tempCart);

                return View(tempCartList);
            }
        }

        // GET: AddOneToTrainingServicesCart
        public async Task<IActionResult> AddOneToTrainingServicesCart(int? id)
        {
            // Code below copied from http://learningprogramming.net/net/asp-net-core-mvc/build-shopping-cart-with-session-in-asp-net-core-mvc/
            // and updated it.

            List<CartItemModel> cart = SessionHelper.GetObjectFromJson<List<CartItemModel>>(HttpContext.Session, "trainingServicesCart");
            int index = isExistTrainingService((int)id);

            if (index != -1)
            {
                cart[index].CartQty++;

                var cartItemModel = await _context.CartItemModel
                .FirstOrDefaultAsync(m => m.TrainingServicesPriceID == id);

                if (cartItemModel == null)
                {
                    return NotFound();
                }

                cartItemModel.CartQty++;

                if (ModelState.IsValid)
                {
                    try
                    {
                        _context.Update(cartItemModel);
                        await _context.SaveChangesAsync();
                    }
                    catch (DbUpdateConcurrencyException)
                    {
                        throw;
                    }
                }
            }

            SessionHelper.SetObjectAsJson(HttpContext.Session, "trainingServicesCart", cart);

            return RedirectToAction("Index");
        }

        // GET: RemoveOneFromTrainingServicesCart
        public async Task<IActionResult> RemoveOneFromTrainingServicesCart(int? id)
        {
            // Code below copied from http://learningprogramming.net/net/asp-net-core-mvc/build-shopping-cart-with-session-in-asp-net-core-mvc/
            // and updated it.

            List<CartItemModel> cart = SessionHelper.GetObjectFromJson<List<CartItemModel>>(HttpContext.Session, "trainingServicesCart");
            int index = isExistTrainingService((int)id);

            if (index != -1)
            {
                if (cart[index].CartQty == 1)
                {
                    cart.RemoveAt(index);

                    var cartItemModel = await _context.CartItemModel
                    .FirstOrDefaultAsync(m => m.TrainingServicesPriceID == id);

                    if (cartItemModel == null)
                    {
                        return NotFound();
                    }

                    _context.CartItemModel.Remove(cartItemModel);
                    await _context.SaveChangesAsync();
                }
                else
                {
                    cart[index].CartQty--;

                    var cartItemModel = await _context.CartItemModel
                    .FirstOrDefaultAsync(m => m.TrainingServicesPriceID == id);

                    if (cartItemModel == null)
                    {
                        return NotFound();
                    }

                    cartItemModel.CartQty--;

                    if (ModelState.IsValid)
                    {
                        try
                        {
                            _context.Update(cartItemModel);
                            await _context.SaveChangesAsync();
                        }
                        catch (DbUpdateConcurrencyException)
                        {
                            throw;
                        }
                    }
                }
            }

            SessionHelper.SetObjectAsJson(HttpContext.Session, "trainingServicesCart", cart);

            return RedirectToAction("Index");
        }

        // GET: BuyPuppy, Authorize code from https://www.red-gate.com/simple-talk/dotnet/asp-net/thoughts-on-asp-net-mvc-authorization-and-security/
        [Authorize]
        public async Task<IActionResult> BuyPuppy(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            // Code below copied from http://learningprogramming.net/net/asp-net-core-mvc/build-shopping-cart-with-session-in-asp-net-core-mvc/
            // and updated it.

            // Get the puppy 
            var pricingPuppyModel = await _context.PricingPuppyModel.FindAsync(id);

            if (pricingPuppyModel == null)
            {
                return NotFound();
            }

            if (SessionHelper.GetObjectFromJson<List<CartItemModel>>(HttpContext.Session, "puppyCart") == null)
            {
                List<CartItemModel> cart = new List<CartItemModel>();
                CartItemModel newCartItem = new CartItemModel { PricePuppyID = pricingPuppyModel.PricePuppyID, PricePuppyDesc = pricingPuppyModel.PricePuppyDesc,
                    PricePuppy = pricingPuppyModel.PricePuppy, TrainingServicesPriceID = -1,
                    TrainingName = "", PriceTraining = 0, CartQty = 1, Email = User.Identity.Name };

                cart.Add(newCartItem);

                if (ModelState.IsValid)
                {
                    _context.Add(newCartItem);
                    await _context.SaveChangesAsync();
                }

                SessionHelper.SetObjectAsJson(HttpContext.Session, "puppyCart", cart);
            }
            else
            {
                List<CartItemModel> cart = SessionHelper.GetObjectFromJson<List<CartItemModel>>(HttpContext.Session, "puppyCart");
                int index = isExistPuppy((int)id);

                if (index == -1)
                {
                    CartItemModel newCartItm = new CartItemModel { PricePuppyID = pricingPuppyModel.PricePuppyID, PricePuppyDesc = pricingPuppyModel.PricePuppyDesc,
                                               PricePuppy = pricingPuppyModel.PricePuppy, TrainingServicesPriceID = -1, TrainingName = "", PriceTraining = 0, CartQty = 1,
                                               Email = User.Identity.Name };
                    cart.Add(newCartItm);

                    if (ModelState.IsValid)
                    {
                        _context.Add(newCartItm);
                        await _context.SaveChangesAsync();
                    }
                }

                SessionHelper.SetObjectAsJson(HttpContext.Session, "puppyCart", cart);
            }

            // Delete the puppy from the pricing puppy table
            //_context.PricingPuppyModel.Remove(pricingPuppyModel);
            //await _context.SaveChangesAsync();


            return RedirectToAction("Index");
        }


        // GET: BuyTrainingService, Authorize code from https://www.red-gate.com/simple-talk/dotnet/asp-net/thoughts-on-asp-net-mvc-authorization-and-security/
        [Authorize]
        public async Task<IActionResult> BuyTrainingService(int? id)
        {
            
            if (id == null)
            {
                return NotFound();
            }

            // Code below copied from http://learningprogramming.net/net/asp-net-core-mvc/build-shopping-cart-with-session-in-asp-net-core-mvc/
            // and updated it.

            // Get the training service
            var trainingServicesPriceModel = await _context.TrainingServicesPriceModel.FindAsync(id);

            if (trainingServicesPriceModel == null)
            {
                return NotFound();
            }

            
            if (SessionHelper.GetObjectFromJson<List<CartItemModel>>(HttpContext.Session, "trainingServicesCart") == null)
            {
                List<CartItemModel> cart = new List<CartItemModel>();

                CartItemModel newCartItem = new CartItemModel { PricePuppyID = -1, PricePuppyDesc = "", PricePuppy = 0,
                                             TrainingServicesPriceID = trainingServicesPriceModel.TrainingServicesPriceID, TrainingName = trainingServicesPriceModel.TrainingName,
                                             PriceTraining = trainingServicesPriceModel.PriceTraining, CartQty = 1, Email = User.Identity.Name };

                cart.Add(newCartItem);

                if (ModelState.IsValid)
                {
                    _context.Add(newCartItem);
                    await _context.SaveChangesAsync();
                }

                SessionHelper.SetObjectAsJson(HttpContext.Session, "trainingServicesCart", cart);
            }
            else
            {
                List<CartItemModel> cart = SessionHelper.GetObjectFromJson<List<CartItemModel>>(HttpContext.Session, "trainingServicesCart");
                int index = isExistTrainingService((int)id);
                if (index != -1)
                {
                    cart[index].CartQty++;

                    var cartItemModel = await _context.CartItemModel
                    .FirstOrDefaultAsync(m => m.TrainingServicesPriceID == id);

                    if (cartItemModel == null)
                    {
                        return NotFound();
                    }

                    cartItemModel.CartQty++;

                    if (ModelState.IsValid)
                    {
                        try
                        {
                            _context.Update(cartItemModel);
                            await _context.SaveChangesAsync();
                        }
                        catch (DbUpdateConcurrencyException)
                        {
                           throw;
                        }
                    }
                }
                else
                {
                    CartItemModel newCartItm = new CartItemModel {PricePuppyID = -1, PricePuppyDesc = "", PricePuppy = 0,
                                               TrainingServicesPriceID = trainingServicesPriceModel.TrainingServicesPriceID, TrainingName = trainingServicesPriceModel.TrainingName,
                                               PriceTraining = trainingServicesPriceModel.PriceTraining, CartQty = 1, Email = User.Identity.Name };

                    cart.Add(newCartItm);

                    if (ModelState.IsValid)
                    {
                        _context.Add(newCartItm);
                        await _context.SaveChangesAsync();
                    }
                }

                SessionHelper.SetObjectAsJson(HttpContext.Session, "trainingServicesCart", cart);
            }

            return RedirectToAction("Index");

        }
        

        
        // GET: Remove puppy
        public async Task<IActionResult> RemovePuppy(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            List<CartItemModel> puppyCart = SessionHelper.GetObjectFromJson<List<CartItemModel>>(HttpContext.Session, "puppyCart");
            int index = isExistPuppy((int)id);

            if (index != -1)
            {
                puppyCart.RemoveAt(index);

                var cartItemModel = await _context.CartItemModel
                    .FirstOrDefaultAsync(m => m.PricePuppyID == id);

                if (cartItemModel == null)
                {
                    return NotFound();
                }

                _context.CartItemModel.Remove(cartItemModel);
                await _context.SaveChangesAsync();
            }

            SessionHelper.SetObjectAsJson(HttpContext.Session, "puppyCart", puppyCart);
           
            return RedirectToAction("Index");
        }
        

        // GET: Remove training service
        public async Task<IActionResult> RemoveTrainingService(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            List<CartItemModel> trainingServicesCart = SessionHelper.GetObjectFromJson<List<CartItemModel>>(HttpContext.Session, "trainingServicesCart");
            int index = isExistTrainingService((int)id);

            if (index != -1)
            {
                trainingServicesCart.RemoveAt(index);

                var cartItemModel = await _context.CartItemModel
                   .FirstOrDefaultAsync(m => m.TrainingServicesPriceID == id);

                if (cartItemModel == null)
                {
                    return NotFound();
                }

                _context.CartItemModel.Remove(cartItemModel);
                await _context.SaveChangesAsync();
            }

            SessionHelper.SetObjectAsJson(HttpContext.Session, "trainingServicesCart", trainingServicesCart);

            return RedirectToAction("Index");
        }

        public async Task<IActionResult> CheckOut()
        {
            List<CartItemModel> puppyCart = SessionHelper.GetObjectFromJson<List<CartItemModel>>(HttpContext.Session, "puppyCart");
            List<CartItemModel> trainingServicesCart = SessionHelper.GetObjectFromJson<List<CartItemModel>>(HttpContext.Session, "trainingServicesCart");

            if (puppyCart != null && trainingServicesCart != null)
                puppyCart.AddRange(trainingServicesCart);

            double puppyTotal = 0;
            double trainingServicesTotal = 0;

            if (puppyCart != null)
            {

                for (int i = 0; i < puppyCart.Count; i++)
                {
                    if (puppyCart[i].TrainingServicesPriceID == -1)
                    {
                        puppyTotal += puppyCart[i].PricePuppy;

                        // Get the puppy 
                        var pricingPuppyModel = await _context.PricingPuppyModel.FindAsync(puppyCart[i].PricePuppyID);

                        if (pricingPuppyModel == null)
                        {
                            return NotFound();
                        }

                        _context.PricingPuppyModel.Remove(pricingPuppyModel);
                        await _context.SaveChangesAsync();
                    }
                    else if (puppyCart[i].PricePuppyID == -1)
                    {
                        trainingServicesTotal += puppyCart[i].PriceTraining * puppyCart[i].CartQty;
                    }
                }

                ViewData["puppyTotal"] = puppyTotal;
                ViewData["trainingServicesTotal"] = trainingServicesTotal;

                List<CartItemModel> emptyCart = new List<CartItemModel>();
                SessionHelper.SetObjectAsJson(HttpContext.Session, "puppyCart", emptyCart);
                SessionHelper.SetObjectAsJson(HttpContext.Session, "trainingServicesCart", emptyCart);

                return View(puppyCart);
            }
            else if (trainingServicesCart != null) {

                for (int i = 0; i < trainingServicesCart.Count; i++)
                {
                    if (trainingServicesCart[i].PricePuppyID == -1)
                    {
                        trainingServicesTotal += trainingServicesCart[i].PriceTraining * trainingServicesCart[i].CartQty;
                    }
                }

                ViewData["puppyTotal"] = puppyTotal;
                ViewData["trainingServicesTotal"] = trainingServicesTotal;

                List<CartItemModel> emptyCart1 = new List<CartItemModel>();
                SessionHelper.SetObjectAsJson(HttpContext.Session, "puppyCart", emptyCart1);
                SessionHelper.SetObjectAsJson(HttpContext.Session, "trainingServicesCart", emptyCart1);

                return View(trainingServicesCart);
            }

            ViewData["puppyTotal"] = puppyTotal;
            ViewData["trainingServicesTotal"] = trainingServicesTotal;

            List<CartItemModel> emptyCart2 = new List<CartItemModel>();
            SessionHelper.SetObjectAsJson(HttpContext.Session, "puppyCart", emptyCart2);
            SessionHelper.SetObjectAsJson(HttpContext.Session, "trainingServicesCart", emptyCart2);

            return View();
        }

        public async Task<IActionResult> CartItemsView()
        {
            return View(await _context.CartItemModel.ToListAsync());
        }

        // GET: CartItemModels/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var cartItemModel = await _context.CartItemModel
                .FirstOrDefaultAsync(m => m.CartId == id);
            if (cartItemModel == null)
            {
                return NotFound();
            }

            return View(cartItemModel);
        }

        // GET: CartItemModels/Create
        public IActionResult Create()
        {
            return View();
        }

        // POST: CartItemModels/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("CartId,PricePuppyID,PricePuppyDesc,PricePuppy,TrainingServicesPriceID,TrainingName,PriceTraining,CartQty,Email")] CartItemModel cartItemModel)
        {
            if (ModelState.IsValid)
            {
                _context.Add(cartItemModel);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            return View(cartItemModel);
        }

        // GET: CartItemModels/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var cartItemModel = await _context.CartItemModel.FindAsync(id);
            if (cartItemModel == null)
            {
                return NotFound();
            }
            return View(cartItemModel);
        }

        // POST: CartItemModels/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("CartId,PricePuppyID,PricePuppyDesc,PricePuppy,TrainingServicesPriceID,TrainingName,PriceTraining,CartQty,Email")] CartItemModel cartItemModel)
        {
            if (id != cartItemModel.CartId)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(cartItemModel);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!CartItemModelExists(cartItemModel.CartId))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            return View(cartItemModel);
        }

        // GET: CartItemModels/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var cartItemModel = await _context.CartItemModel
                .FirstOrDefaultAsync(m => m.CartId == id);
            if (cartItemModel == null)
            {
                return NotFound();
            }

            return View(cartItemModel);
        }

        // POST: CartItemModels/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var cartItemModel = await _context.CartItemModel.FindAsync(id);
            _context.CartItemModel.Remove(cartItemModel);
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool CartItemModelExists(int id)
        {
            return _context.CartItemModel.Any(e => e.CartId == id);
        }

        // Code below copied from http://learningprogramming.net/net/asp-net-core-mvc/build-shopping-cart-with-session-in-asp-net-core-mvc/
        // and updated it.

        private int isExistPuppy(int id)
        {
            List<CartItemModel> cart = SessionHelper.GetObjectFromJson<List<CartItemModel>>(HttpContext.Session, "puppyCart");

            for (int i = 0; i < cart.Count; i++)
            {
                if (cart[i].PricePuppyID.Equals(id))
                {
                    return i;
                }
            }
            return -1;
        }

        private int isExistTrainingService(int id)
        {
            List<CartItemModel> cart = SessionHelper.GetObjectFromJson<List<CartItemModel>>(HttpContext.Session, "trainingServicesCart");

            for (int i = 0; i < cart.Count; i++)
            {
                if (cart[i].TrainingServicesPriceID.Equals(id))
                {
                    return i;
                }
            }
            return -1;
        }

    }
}
