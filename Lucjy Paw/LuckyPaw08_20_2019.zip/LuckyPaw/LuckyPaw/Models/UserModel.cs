using System;
using System.Collections.Generic;
using Microsoft.AspNetCore.Identity;

namespace LuckyPaw.Models
{
    public class UserModel
    {
        public List<IdentityUser> userList { get; set; }

        public List<IdentityRole> roleList { get; set; }

        public List<IdentityUserRole<string>> userRoleList { get; set; }
    }
}